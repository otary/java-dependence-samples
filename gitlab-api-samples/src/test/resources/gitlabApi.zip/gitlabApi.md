---
title: gitlabApi
language_tabs:
  - shell: Shell
  - http: HTTP
  - javascript: JavaScript
  - ruby: Ruby
  - python: Python
  - php: PHP
  - java: Java
  - go: Go
toc_footers: []
includes: []
search: true
code_clipboard: true
highlight_theme: darkula
headingLevel: 2
generator: "@tarslib/widdershins v4.0.23"

---

# gitlabApi

Base URLs:

# Authentication

# Default

## GET 列出所有命名空间

GET /api/v4/namespaces

### 请求参数

|名称|位置|类型|必选|说明|
|---|---|---|---|---|
|Authorization|header|string| 否 |none|
|Content-Type|header|string| 否 |none|

> 返回示例

> 200 Response

```json
{}
```

### 返回结果

|状态码|状态码含义|说明|数据模型|
|---|---|---|---|
|200|[OK](https://tools.ietf.org/html/rfc7231#section-6.3.1)|成功|Inline|

### 返回数据结构

## GET 获取指定群组的命名空间

GET /api/v4/namespaces/{groups}

### 请求参数

|名称|位置|类型|必选|说明|
|---|---|---|---|---|
|groups|path|string| 是 |none|
|Authorization|header|string| 否 |none|
|Content-Type|header|string| 否 |none|

> 返回示例

> 200 Response

```json
{}
```

### 返回结果

|状态码|状态码含义|说明|数据模型|
|---|---|---|---|
|200|[OK](https://tools.ietf.org/html/rfc7231#section-6.3.1)|成功|Inline|

### 返回数据结构

## POST 获取 access-token

POST /oauth/token

> Body 请求参数

```json
{
  "grant_type": "password",
  "username": "user@example.com",
  "password": "secret"
}
```

### 请求参数

|名称|位置|类型|必选|说明|
|---|---|---|---|---|
|body|body|object| 否 |none|
|» grant_type|body|string| 是 |none|
|» username|body|string| 是 |none|
|» password|body|string| 是 |none|

> 返回示例

> 成功

```json
{
  "access_token": "5dab167d0b717481bf9909f08932f311f623d763335659d16da8f4958b00669d",
  "token_type": "Bearer",
  "expires_in": 7200,
  "refresh_token": "0efffe55e41ad35294ed4d2c8715a5acb5734f419a8cc5f87d7d9e06f8fb29e9",
  "scope": "api",
  "created_at": 1687945180
}
```

### 返回结果

|状态码|状态码含义|说明|数据模型|
|---|---|---|---|
|200|[OK](https://tools.ietf.org/html/rfc7231#section-6.3.1)|成功|Inline|

### 返回数据结构

状态码 **200**

|名称|类型|必选|约束|中文名|说明|
|---|---|---|---|---|---|
|» access_token|string|true|none||none|
|» token_type|string|true|none||none|
|» expires_in|integer|true|none||none|
|» refresh_token|string|true|none||none|
|» scope|string|true|none||none|
|» created_at|integer|true|none||none|

## POST 测试webhook

POST /api/v4//hooks/{id}

### 请求参数

|名称|位置|类型|必选|说明|
|---|---|---|---|---|
|id|path|string| 是 |none|
|Authorization|header|string| 否 |none|

> 返回示例

> 200 Response

```json
{}
```

### 返回结果

|状态码|状态码含义|说明|数据模型|
|---|---|---|---|
|200|[OK](https://tools.ietf.org/html/rfc7231#section-6.3.1)|成功|Inline|

### 返回数据结构

## GET 获取所有项目

GET /api/v4/projects

> 返回示例

> 200 Response

```json
{}
```

### 返回结果

|状态码|状态码含义|说明|数据模型|
|---|---|---|---|
|200|[OK](https://tools.ietf.org/html/rfc7231#section-6.3.1)|成功|Inline|

### 返回数据结构

## GET 未命名接口

GET /api/v1/code/ci/repository/download/{id}

### 请求参数

|名称|位置|类型|必选|说明|
|---|---|---|---|---|
|id|path|string| 是 |none|

> 返回示例

> 200 Response

```json
{}
```

### 返回结果

|状态码|状态码含义|说明|数据模型|
|---|---|---|---|
|200|[OK](https://tools.ietf.org/html/rfc7231#section-6.3.1)|成功|Inline|

### 返回数据结构

## PATCH 未命名接口

PATCH /api/v4/projects/530/protected_branches/dev

### 请求参数

|名称|位置|类型|必选|说明|
|---|---|---|---|---|
|allow_force_push|query|string| 否 |none|

> 返回示例

> 200 Response

```json
{}
```

### 返回结果

|状态码|状态码含义|说明|数据模型|
|---|---|---|---|
|200|[OK](https://tools.ietf.org/html/rfc7231#section-6.3.1)|成功|Inline|

### 返回数据结构

## GET 未命名接口

GET /oauth/authorize

### 请求参数

|名称|位置|类型|必选|说明|
|---|---|---|---|---|
|response_type|query|string| 否 |none|
|state|query|string| 否 |none|
|scope|query|string| 否 |none|
|client_id|query|string| 否 |none|
|redirect_uri|query|string| 否 |none|

> 返回示例

> 200 Response

```json
{}
```

### 返回结果

|状态码|状态码含义|说明|数据模型|
|---|---|---|---|
|200|[OK](https://tools.ietf.org/html/rfc7231#section-6.3.1)|成功|Inline|

### 返回数据结构

# project

## POST 创建项目（通过命名空间ID 区分是群组创建还是个人创建）

POST /api/v4/projects/

> Body 请求参数

```json
{
  "name": "new_project",
  "description": "New Project",
  "path": "new_project",
  "namespace_id": "42",
  "initialize_with_readme": "true"
}
```

### 请求参数

|名称|位置|类型|必选|说明|
|---|---|---|---|---|
|Authorization|header|string| 否 |none|
|Content-Type|header|string| 否 |none|
|body|body|object| 否 |none|
|» name|body|string| 是 |none|
|» description|body|string| 是 |none|
|» path|body|string| 是 |none|
|» namespace_id|body|string| 是 |none|
|» initialize_with_readme|body|string| 是 |none|

> 返回示例

> 200 Response

```json
{}
```

### 返回结果

|状态码|状态码含义|说明|数据模型|
|---|---|---|---|
|200|[OK](https://tools.ietf.org/html/rfc7231#section-6.3.1)|成功|Inline|

### 返回数据结构

## GET 列出所有项目

GET /api/v4/projects/48/deploy_keys

### 请求参数

|名称|位置|类型|必选|说明|
|---|---|---|---|---|
|Authorization|header|string| 否 |none|
|Content-Type|header|string| 否 |none|

> 返回示例

> 200 Response

```json
{}
```

### 返回结果

|状态码|状态码含义|说明|数据模型|
|---|---|---|---|
|200|[OK](https://tools.ietf.org/html/rfc7231#section-6.3.1)|成功|Inline|

### 返回数据结构

## GET 从指定仓库获取文件

GET /api/v4/projects/{id}/repository/files/{file_path}

### 请求参数

|名称|位置|类型|必选|说明|
|---|---|---|---|---|
|id|path|integer| 是 |none|
|file_path|path|string| 是 |none|
|ref|query|string| 否 |none|
|Authorization|header|string| 否 |none|
|Content-Type|header|string| 否 |none|

> 返回示例

> 200 Response

```json
{}
```

### 返回结果

|状态码|状态码含义|说明|数据模型|
|---|---|---|---|
|200|[OK](https://tools.ietf.org/html/rfc7231#section-6.3.1)|成功|Inline|

### 返回数据结构

## GET 列出仓库树

GET /api/v4/projects/{id}/repository/tree/{path}

### 请求参数

|名称|位置|类型|必选|说明|
|---|---|---|---|---|
|id|path|integer| 是 |none|
|path|path|string| 是 |none|
|Authorization|header|string| 否 |none|
|Content-Type|header|string| 否 |none|

> 返回示例

> 200 Response

```json
{}
```

### 返回结果

|状态码|状态码含义|说明|数据模型|
|---|---|---|---|
|200|[OK](https://tools.ietf.org/html/rfc7231#section-6.3.1)|成功|Inline|

### 返回数据结构

## GET 列出指定仓库提交记录

GET /api/v4/projects/{id}/repository/commits

### 请求参数

|名称|位置|类型|必选|说明|
|---|---|---|---|---|
|id|path|integer| 是 |none|
|Authorization|header|string| 否 |none|
|Content-Type|header|string| 否 |none|

> 返回示例

> 200 Response

```json
{}
```

### 返回结果

|状态码|状态码含义|说明|数据模型|
|---|---|---|---|
|200|[OK](https://tools.ietf.org/html/rfc7231#section-6.3.1)|成功|Inline|

### 返回数据结构

## GET 指定两个不同的sha对比

GET /api/v4/projects/{id}/repository/compare

### 请求参数

|名称|位置|类型|必选|说明|
|---|---|---|---|---|
|id|path|integer| 是 |none|
|form|query|string| 否 |none|
|to|query|string| 否 |none|
|Authorization|header|string| 否 |none|
|Content-Type|header|string| 否 |none|

> 返回示例

> 200 Response

```json
{}
```

### 返回结果

|状态码|状态码含义|说明|数据模型|
|---|---|---|---|
|200|[OK](https://tools.ietf.org/html/rfc7231#section-6.3.1)|成功|Inline|

### 返回数据结构

## GET 获取指定仓库提交差异

GET /api/v4/projects/{id}/repository/commits/{sha}/diff

### 请求参数

|名称|位置|类型|必选|说明|
|---|---|---|---|---|
|id|path|integer| 是 |none|
|sha|path|string| 是 |none|
|Authorization|header|string| 否 |none|
|Content-Type|header|string| 否 |none|

> 返回示例

> 200 Response

```json
{}
```

### 返回结果

|状态码|状态码含义|说明|数据模型|
|---|---|---|---|
|200|[OK](https://tools.ietf.org/html/rfc7231#section-6.3.1)|成功|Inline|

### 返回数据结构

## GET 获取指定项目信息

GET /api/v4/projects/{id}

### 请求参数

|名称|位置|类型|必选|说明|
|---|---|---|---|---|
|id|path|integer| 是 |none|
|Authorization|header|string| 否 |none|
|Content-Type|header|string| 否 |none|

> 返回示例

> 成功

```json
{
  "id": 47261069,
  "description": "这是个接口测试创建项目的接口",
  "name": "hdq_test",
  "name_with_namespace": "dengquan huang / hdq_test",
  "path": "hdq_test",
  "path_with_namespace": "hdengquan4/hdq_test",
  "created_at": "2023-06-29T08:25:35.482Z",
  "default_branch": "main",
  "tag_list": [],
  "topics": [],
  "ssh_url_to_repo": "git@gitlab.com:hdengquan4/hdq_test.git",
  "http_url_to_repo": "https://gitlab.com/hdengquan4/hdq_test.git",
  "web_url": "https://gitlab.com/hdengquan4/hdq_test",
  "readme_url": "https://gitlab.com/hdengquan4/hdq_test/-/blob/main/README.md",
  "forks_count": 0,
  "avatar_url": null,
  "star_count": 0,
  "last_activity_at": "2023-06-29T08:25:35.482Z",
  "namespace": {
    "id": 69277559,
    "name": "dengquan huang",
    "path": "hdengquan4",
    "kind": "user",
    "full_path": "hdengquan4",
    "parent_id": null,
    "avatar_url": "https://secure.gravatar.com/avatar/cc08dd76f76291e2b806cbe3f21b32ac?s=80&d=identicon",
    "web_url": "https://gitlab.com/hdengquan4"
  },
  "container_registry_image_prefix": "registry.gitlab.com/hdengquan4/hdq_test",
  "_links": {
    "self": "https://gitlab.com/api/v4/projects/47261069",
    "issues": "https://gitlab.com/api/v4/projects/47261069/issues",
    "merge_requests": "https://gitlab.com/api/v4/projects/47261069/merge_requests",
    "repo_branches": "https://gitlab.com/api/v4/projects/47261069/repository/branches",
    "labels": "https://gitlab.com/api/v4/projects/47261069/labels",
    "events": "https://gitlab.com/api/v4/projects/47261069/events",
    "members": "https://gitlab.com/api/v4/projects/47261069/members",
    "cluster_agents": "https://gitlab.com/api/v4/projects/47261069/cluster_agents"
  },
  "packages_enabled": true,
  "empty_repo": false,
  "archived": false,
  "visibility": "private",
  "owner": {
    "id": 14948797,
    "username": "hdengquan4",
    "name": "dengquan huang",
    "state": "active",
    "avatar_url": "https://secure.gravatar.com/avatar/cc08dd76f76291e2b806cbe3f21b32ac?s=80&d=identicon",
    "web_url": "https://gitlab.com/hdengquan4"
  },
  "resolve_outdated_diff_discussions": false,
  "container_expiration_policy": {
    "cadence": "1d",
    "enabled": false,
    "keep_n": 10,
    "older_than": "90d",
    "name_regex": ".*",
    "name_regex_keep": null,
    "next_run_at": "2023-06-30T08:25:35.519Z"
  },
  "issues_enabled": true,
  "merge_requests_enabled": true,
  "wiki_enabled": true,
  "jobs_enabled": true,
  "snippets_enabled": true,
  "container_registry_enabled": true,
  "service_desk_enabled": true,
  "service_desk_address": "contact-project+hdengquan4-hdq-test-47261069-issue-@incoming.gitlab.com",
  "can_create_merge_request_in": true,
  "issues_access_level": "enabled",
  "repository_access_level": "enabled",
  "merge_requests_access_level": "enabled",
  "forking_access_level": "enabled",
  "wiki_access_level": "enabled",
  "builds_access_level": "enabled",
  "snippets_access_level": "enabled",
  "pages_access_level": "private",
  "analytics_access_level": "enabled",
  "container_registry_access_level": "enabled",
  "security_and_compliance_access_level": "private",
  "releases_access_level": "enabled",
  "environments_access_level": "enabled",
  "feature_flags_access_level": "enabled",
  "infrastructure_access_level": "enabled",
  "monitor_access_level": "enabled",
  "emails_disabled": null,
  "shared_runners_enabled": true,
  "lfs_enabled": true,
  "creator_id": 14948797,
  "import_url": null,
  "import_type": null,
  "import_status": "none",
  "import_error": null,
  "open_issues_count": 0,
  "description_html": "<p data-sourcepos=\"1:1-1:42\" dir=\"auto\">这是个接口测试创建项目的接口</p>",
  "updated_at": "2023-06-29T08:25:36.435Z",
  "ci_default_git_depth": 20,
  "ci_forward_deployment_enabled": true,
  "ci_job_token_scope_enabled": false,
  "ci_separated_caches": true,
  "ci_allow_fork_pipelines_to_run_in_parent_project": true,
  "build_git_strategy": "fetch",
  "keep_latest_artifact": true,
  "restrict_user_defined_variables": false,
  "runners_token": "GR13489415m_RkCywW-D16MtzKVCp",
  "runner_token_expiration_interval": null,
  "group_runners_enabled": true,
  "auto_cancel_pending_pipelines": "enabled",
  "build_timeout": 3600,
  "auto_devops_enabled": false,
  "auto_devops_deploy_strategy": "continuous",
  "ci_config_path": "",
  "public_jobs": true,
  "shared_with_groups": [],
  "only_allow_merge_if_pipeline_succeeds": false,
  "allow_merge_on_skipped_pipeline": null,
  "request_access_enabled": true,
  "only_allow_merge_if_all_discussions_are_resolved": false,
  "remove_source_branch_after_merge": true,
  "printing_merge_request_link_enabled": true,
  "merge_method": "merge",
  "squash_option": "default_off",
  "enforce_auth_checks_on_uploads": true,
  "suggestion_commit_message": null,
  "merge_commit_template": null,
  "squash_commit_template": null,
  "issue_branch_template": null,
  "autoclose_referenced_issues": true,
  "external_authorization_classification_label": "",
  "requirements_enabled": false,
  "requirements_access_level": "enabled",
  "security_and_compliance_enabled": true,
  "compliance_frameworks": [],
  "permissions": {
    "project_access": {
      "access_level": 50,
      "notification_level": 3
    },
    "group_access": null
  }
}
```

### 返回结果

|状态码|状态码含义|说明|数据模型|
|---|---|---|---|
|200|[OK](https://tools.ietf.org/html/rfc7231#section-6.3.1)|成功|Inline|

### 返回数据结构

状态码 **200**

|名称|类型|必选|约束|中文名|说明|
|---|---|---|---|---|---|
|» id|integer|true|none||none|
|» description|string|true|none||none|
|» name|string|true|none||none|
|» name_with_namespace|string|true|none||none|
|» path|string|true|none||none|
|» path_with_namespace|string|true|none||none|
|» created_at|string|true|none||none|
|» default_branch|string|true|none||none|
|» tag_list|[string]|true|none||none|
|» topics|[string]|true|none||none|
|» ssh_url_to_repo|string|true|none||none|
|» http_url_to_repo|string|true|none||none|
|» web_url|string|true|none||none|
|» readme_url|string|true|none||none|
|» forks_count|integer|true|none||none|
|» avatar_url|null|true|none||none|
|» star_count|integer|true|none||none|
|» last_activity_at|string|true|none||none|
|» namespace|object|true|none||none|
|»» id|integer|true|none||none|
|»» name|string|true|none||none|
|»» path|string|true|none||none|
|»» kind|string|true|none||none|
|»» full_path|string|true|none||none|
|»» parent_id|null|true|none||none|
|»» avatar_url|string|true|none||none|
|»» web_url|string|true|none||none|
|» container_registry_image_prefix|string|true|none||none|
|» _links|object|true|none||none|
|»» self|string|true|none||none|
|»» issues|string|true|none||none|
|»» merge_requests|string|true|none||none|
|»» repo_branches|string|true|none||none|
|»» labels|string|true|none||none|
|»» events|string|true|none||none|
|»» members|string|true|none||none|
|»» cluster_agents|string|true|none||none|
|» packages_enabled|boolean|true|none||none|
|» empty_repo|boolean|true|none||none|
|» archived|boolean|true|none||none|
|» visibility|string|true|none||none|
|» owner|object|true|none||none|
|»» id|integer|true|none||none|
|»» username|string|true|none||none|
|»» name|string|true|none||none|
|»» state|string|true|none||none|
|»» avatar_url|string|true|none||none|
|»» web_url|string|true|none||none|
|» resolve_outdated_diff_discussions|boolean|true|none||none|
|» container_expiration_policy|object|true|none||none|
|»» cadence|string|true|none||none|
|»» enabled|boolean|true|none||none|
|»» keep_n|integer|true|none||none|
|»» older_than|string|true|none||none|
|»» name_regex|string|true|none||none|
|»» name_regex_keep|null|true|none||none|
|»» next_run_at|string|true|none||none|
|» issues_enabled|boolean|true|none||none|
|» merge_requests_enabled|boolean|true|none||none|
|» wiki_enabled|boolean|true|none||none|
|» jobs_enabled|boolean|true|none||none|
|» snippets_enabled|boolean|true|none||none|
|» container_registry_enabled|boolean|true|none||none|
|» service_desk_enabled|boolean|true|none||none|
|» service_desk_address|string|true|none||none|
|» can_create_merge_request_in|boolean|true|none||none|
|» issues_access_level|string|true|none||none|
|» repository_access_level|string|true|none||none|
|» merge_requests_access_level|string|true|none||none|
|» forking_access_level|string|true|none||none|
|» wiki_access_level|string|true|none||none|
|» builds_access_level|string|true|none||none|
|» snippets_access_level|string|true|none||none|
|» pages_access_level|string|true|none||none|
|» analytics_access_level|string|true|none||none|
|» container_registry_access_level|string|true|none||none|
|» security_and_compliance_access_level|string|true|none||none|
|» releases_access_level|string|true|none||none|
|» environments_access_level|string|true|none||none|
|» feature_flags_access_level|string|true|none||none|
|» infrastructure_access_level|string|true|none||none|
|» monitor_access_level|string|true|none||none|
|» emails_disabled|null|true|none||none|
|» shared_runners_enabled|boolean|true|none||none|
|» lfs_enabled|boolean|true|none||none|
|» creator_id|integer|true|none||none|
|» import_url|null|true|none||none|
|» import_type|null|true|none||none|
|» import_status|string|true|none||none|
|» import_error|null|true|none||none|
|» open_issues_count|integer|true|none||none|
|» description_html|string|true|none||none|
|» updated_at|string|true|none||none|
|» ci_default_git_depth|integer|true|none||none|
|» ci_forward_deployment_enabled|boolean|true|none||none|
|» ci_job_token_scope_enabled|boolean|true|none||none|
|» ci_separated_caches|boolean|true|none||none|
|» ci_allow_fork_pipelines_to_run_in_parent_project|boolean|true|none||none|
|» build_git_strategy|string|true|none||none|
|» keep_latest_artifact|boolean|true|none||none|
|» restrict_user_defined_variables|boolean|true|none||none|
|» runners_token|string|true|none||none|
|» runner_token_expiration_interval|null|true|none||none|
|» group_runners_enabled|boolean|true|none||none|
|» auto_cancel_pending_pipelines|string|true|none||none|
|» build_timeout|integer|true|none||none|
|» auto_devops_enabled|boolean|true|none||none|
|» auto_devops_deploy_strategy|string|true|none||none|
|» ci_config_path|string|true|none||none|
|» public_jobs|boolean|true|none||none|
|» shared_with_groups|[string]|true|none||none|
|» only_allow_merge_if_pipeline_succeeds|boolean|true|none||none|
|» allow_merge_on_skipped_pipeline|null|true|none||none|
|» request_access_enabled|boolean|true|none||none|
|» only_allow_merge_if_all_discussions_are_resolved|boolean|true|none||none|
|» remove_source_branch_after_merge|boolean|true|none||none|
|» printing_merge_request_link_enabled|boolean|true|none||none|
|» merge_method|string|true|none||none|
|» squash_option|string|true|none||none|
|» enforce_auth_checks_on_uploads|boolean|true|none||none|
|» suggestion_commit_message|null|true|none||none|
|» merge_commit_template|null|true|none||none|
|» squash_commit_template|null|true|none||none|
|» issue_branch_template|null|true|none||none|
|» autoclose_referenced_issues|boolean|true|none||none|
|» external_authorization_classification_label|string|true|none||none|
|» requirements_enabled|boolean|true|none||none|
|» requirements_access_level|string|true|none||none|
|» security_and_compliance_enabled|boolean|true|none||none|
|» compliance_frameworks|[string]|true|none||none|
|» permissions|object|true|none||none|
|»» project_access|object|true|none||none|
|»»» access_level|integer|true|none||none|
|»»» notification_level|integer|true|none||none|
|»» group_access|null|true|none||none|

## PUT 更新指定项目信息

PUT /api/v4/projects/{id}

> Body 请求参数

```json
{
  "id": "47262086",
  "path": "hdq_team_test"
}
```

### 请求参数

|名称|位置|类型|必选|说明|
|---|---|---|---|---|
|id|path|string| 是 |none|
|Authorization|header|string| 否 |none|
|Content-Type|header|string| 否 |none|
|body|body|object| 否 |none|
|» id|body|integer| 是 |none|

> 返回示例

> 成功

```json
{
  "id": 47261069,
  "description": "这是个接口测试创建项目的接口",
  "name": "hdq_test",
  "name_with_namespace": "dengquan huang / hdq_test",
  "path": "hdq_test",
  "path_with_namespace": "hdengquan4/hdq_test",
  "created_at": "2023-06-29T08:25:35.482Z",
  "default_branch": "main",
  "tag_list": [],
  "topics": [],
  "ssh_url_to_repo": "git@gitlab.com:hdengquan4/hdq_test.git",
  "http_url_to_repo": "https://gitlab.com/hdengquan4/hdq_test.git",
  "web_url": "https://gitlab.com/hdengquan4/hdq_test",
  "readme_url": "https://gitlab.com/hdengquan4/hdq_test/-/blob/main/README.md",
  "forks_count": 0,
  "avatar_url": null,
  "star_count": 0,
  "last_activity_at": "2023-06-29T08:25:35.482Z",
  "namespace": {
    "id": 69277559,
    "name": "dengquan huang",
    "path": "hdengquan4",
    "kind": "user",
    "full_path": "hdengquan4",
    "parent_id": null,
    "avatar_url": "https://secure.gravatar.com/avatar/cc08dd76f76291e2b806cbe3f21b32ac?s=80&d=identicon",
    "web_url": "https://gitlab.com/hdengquan4"
  },
  "container_registry_image_prefix": "registry.gitlab.com/hdengquan4/hdq_test",
  "_links": {
    "self": "https://gitlab.com/api/v4/projects/47261069",
    "issues": "https://gitlab.com/api/v4/projects/47261069/issues",
    "merge_requests": "https://gitlab.com/api/v4/projects/47261069/merge_requests",
    "repo_branches": "https://gitlab.com/api/v4/projects/47261069/repository/branches",
    "labels": "https://gitlab.com/api/v4/projects/47261069/labels",
    "events": "https://gitlab.com/api/v4/projects/47261069/events",
    "members": "https://gitlab.com/api/v4/projects/47261069/members",
    "cluster_agents": "https://gitlab.com/api/v4/projects/47261069/cluster_agents"
  },
  "packages_enabled": true,
  "empty_repo": false,
  "archived": false,
  "visibility": "private",
  "owner": {
    "id": 14948797,
    "username": "hdengquan4",
    "name": "dengquan huang",
    "state": "active",
    "avatar_url": "https://secure.gravatar.com/avatar/cc08dd76f76291e2b806cbe3f21b32ac?s=80&d=identicon",
    "web_url": "https://gitlab.com/hdengquan4"
  },
  "resolve_outdated_diff_discussions": false,
  "container_expiration_policy": {
    "cadence": "1d",
    "enabled": false,
    "keep_n": 10,
    "older_than": "90d",
    "name_regex": ".*",
    "name_regex_keep": null,
    "next_run_at": "2023-06-30T08:25:35.519Z"
  },
  "issues_enabled": true,
  "merge_requests_enabled": true,
  "wiki_enabled": true,
  "jobs_enabled": true,
  "snippets_enabled": true,
  "container_registry_enabled": true,
  "service_desk_enabled": true,
  "service_desk_address": "contact-project+hdengquan4-hdq-test-47261069-issue-@incoming.gitlab.com",
  "can_create_merge_request_in": true,
  "issues_access_level": "enabled",
  "repository_access_level": "enabled",
  "merge_requests_access_level": "enabled",
  "forking_access_level": "enabled",
  "wiki_access_level": "enabled",
  "builds_access_level": "enabled",
  "snippets_access_level": "enabled",
  "pages_access_level": "private",
  "analytics_access_level": "enabled",
  "container_registry_access_level": "enabled",
  "security_and_compliance_access_level": "private",
  "releases_access_level": "enabled",
  "environments_access_level": "enabled",
  "feature_flags_access_level": "enabled",
  "infrastructure_access_level": "enabled",
  "monitor_access_level": "enabled",
  "emails_disabled": null,
  "shared_runners_enabled": true,
  "lfs_enabled": true,
  "creator_id": 14948797,
  "import_url": null,
  "import_type": null,
  "import_status": "none",
  "import_error": null,
  "open_issues_count": 0,
  "description_html": "<p data-sourcepos=\"1:1-1:42\" dir=\"auto\">这是个接口测试创建项目的接口</p>",
  "updated_at": "2023-06-29T08:25:36.435Z",
  "ci_default_git_depth": 20,
  "ci_forward_deployment_enabled": true,
  "ci_job_token_scope_enabled": false,
  "ci_separated_caches": true,
  "ci_allow_fork_pipelines_to_run_in_parent_project": true,
  "build_git_strategy": "fetch",
  "keep_latest_artifact": true,
  "restrict_user_defined_variables": false,
  "runners_token": "GR13489415m_RkCywW-D16MtzKVCp",
  "runner_token_expiration_interval": null,
  "group_runners_enabled": true,
  "auto_cancel_pending_pipelines": "enabled",
  "build_timeout": 3600,
  "auto_devops_enabled": false,
  "auto_devops_deploy_strategy": "continuous",
  "ci_config_path": "",
  "public_jobs": true,
  "shared_with_groups": [],
  "only_allow_merge_if_pipeline_succeeds": false,
  "allow_merge_on_skipped_pipeline": null,
  "request_access_enabled": true,
  "only_allow_merge_if_all_discussions_are_resolved": false,
  "remove_source_branch_after_merge": true,
  "printing_merge_request_link_enabled": true,
  "merge_method": "merge",
  "squash_option": "default_off",
  "enforce_auth_checks_on_uploads": true,
  "suggestion_commit_message": null,
  "merge_commit_template": null,
  "squash_commit_template": null,
  "issue_branch_template": null,
  "autoclose_referenced_issues": true,
  "external_authorization_classification_label": "",
  "requirements_enabled": false,
  "requirements_access_level": "enabled",
  "security_and_compliance_enabled": true,
  "compliance_frameworks": [],
  "permissions": {
    "project_access": {
      "access_level": 50,
      "notification_level": 3
    },
    "group_access": null
  }
}
```

### 返回结果

|状态码|状态码含义|说明|数据模型|
|---|---|---|---|
|200|[OK](https://tools.ietf.org/html/rfc7231#section-6.3.1)|成功|Inline|

### 返回数据结构

状态码 **200**

|名称|类型|必选|约束|中文名|说明|
|---|---|---|---|---|---|
|» id|integer|true|none||none|
|» description|string|true|none||none|
|» name|string|true|none||none|
|» name_with_namespace|string|true|none||none|
|» path|string|true|none||none|
|» path_with_namespace|string|true|none||none|
|» created_at|string|true|none||none|
|» default_branch|string|true|none||none|
|» tag_list|[string]|true|none||none|
|» topics|[string]|true|none||none|
|» ssh_url_to_repo|string|true|none||none|
|» http_url_to_repo|string|true|none||none|
|» web_url|string|true|none||none|
|» readme_url|string|true|none||none|
|» forks_count|integer|true|none||none|
|» avatar_url|null|true|none||none|
|» star_count|integer|true|none||none|
|» last_activity_at|string|true|none||none|
|» namespace|object|true|none||none|
|»» id|integer|true|none||none|
|»» name|string|true|none||none|
|»» path|string|true|none||none|
|»» kind|string|true|none||none|
|»» full_path|string|true|none||none|
|»» parent_id|null|true|none||none|
|»» avatar_url|string|true|none||none|
|»» web_url|string|true|none||none|
|» container_registry_image_prefix|string|true|none||none|
|» _links|object|true|none||none|
|»» self|string|true|none||none|
|»» issues|string|true|none||none|
|»» merge_requests|string|true|none||none|
|»» repo_branches|string|true|none||none|
|»» labels|string|true|none||none|
|»» events|string|true|none||none|
|»» members|string|true|none||none|
|»» cluster_agents|string|true|none||none|
|» packages_enabled|boolean|true|none||none|
|» empty_repo|boolean|true|none||none|
|» archived|boolean|true|none||none|
|» visibility|string|true|none||none|
|» owner|object|true|none||none|
|»» id|integer|true|none||none|
|»» username|string|true|none||none|
|»» name|string|true|none||none|
|»» state|string|true|none||none|
|»» avatar_url|string|true|none||none|
|»» web_url|string|true|none||none|
|» resolve_outdated_diff_discussions|boolean|true|none||none|
|» container_expiration_policy|object|true|none||none|
|»» cadence|string|true|none||none|
|»» enabled|boolean|true|none||none|
|»» keep_n|integer|true|none||none|
|»» older_than|string|true|none||none|
|»» name_regex|string|true|none||none|
|»» name_regex_keep|null|true|none||none|
|»» next_run_at|string|true|none||none|
|» issues_enabled|boolean|true|none||none|
|» merge_requests_enabled|boolean|true|none||none|
|» wiki_enabled|boolean|true|none||none|
|» jobs_enabled|boolean|true|none||none|
|» snippets_enabled|boolean|true|none||none|
|» container_registry_enabled|boolean|true|none||none|
|» service_desk_enabled|boolean|true|none||none|
|» service_desk_address|string|true|none||none|
|» can_create_merge_request_in|boolean|true|none||none|
|» issues_access_level|string|true|none||none|
|» repository_access_level|string|true|none||none|
|» merge_requests_access_level|string|true|none||none|
|» forking_access_level|string|true|none||none|
|» wiki_access_level|string|true|none||none|
|» builds_access_level|string|true|none||none|
|» snippets_access_level|string|true|none||none|
|» pages_access_level|string|true|none||none|
|» analytics_access_level|string|true|none||none|
|» container_registry_access_level|string|true|none||none|
|» security_and_compliance_access_level|string|true|none||none|
|» releases_access_level|string|true|none||none|
|» environments_access_level|string|true|none||none|
|» feature_flags_access_level|string|true|none||none|
|» infrastructure_access_level|string|true|none||none|
|» monitor_access_level|string|true|none||none|
|» emails_disabled|null|true|none||none|
|» shared_runners_enabled|boolean|true|none||none|
|» lfs_enabled|boolean|true|none||none|
|» creator_id|integer|true|none||none|
|» import_url|null|true|none||none|
|» import_type|null|true|none||none|
|» import_status|string|true|none||none|
|» import_error|null|true|none||none|
|» open_issues_count|integer|true|none||none|
|» description_html|string|true|none||none|
|» updated_at|string|true|none||none|
|» ci_default_git_depth|integer|true|none||none|
|» ci_forward_deployment_enabled|boolean|true|none||none|
|» ci_job_token_scope_enabled|boolean|true|none||none|
|» ci_separated_caches|boolean|true|none||none|
|» ci_allow_fork_pipelines_to_run_in_parent_project|boolean|true|none||none|
|» build_git_strategy|string|true|none||none|
|» keep_latest_artifact|boolean|true|none||none|
|» restrict_user_defined_variables|boolean|true|none||none|
|» runners_token|string|true|none||none|
|» runner_token_expiration_interval|null|true|none||none|
|» group_runners_enabled|boolean|true|none||none|
|» auto_cancel_pending_pipelines|string|true|none||none|
|» build_timeout|integer|true|none||none|
|» auto_devops_enabled|boolean|true|none||none|
|» auto_devops_deploy_strategy|string|true|none||none|
|» ci_config_path|string|true|none||none|
|» public_jobs|boolean|true|none||none|
|» shared_with_groups|[string]|true|none||none|
|» only_allow_merge_if_pipeline_succeeds|boolean|true|none||none|
|» allow_merge_on_skipped_pipeline|null|true|none||none|
|» request_access_enabled|boolean|true|none||none|
|» only_allow_merge_if_all_discussions_are_resolved|boolean|true|none||none|
|» remove_source_branch_after_merge|boolean|true|none||none|
|» printing_merge_request_link_enabled|boolean|true|none||none|
|» merge_method|string|true|none||none|
|» squash_option|string|true|none||none|
|» enforce_auth_checks_on_uploads|boolean|true|none||none|
|» suggestion_commit_message|null|true|none||none|
|» merge_commit_template|null|true|none||none|
|» squash_commit_template|null|true|none||none|
|» issue_branch_template|null|true|none||none|
|» autoclose_referenced_issues|boolean|true|none||none|
|» external_authorization_classification_label|string|true|none||none|
|» requirements_enabled|boolean|true|none||none|
|» requirements_access_level|string|true|none||none|
|» security_and_compliance_enabled|boolean|true|none||none|
|» compliance_frameworks|[string]|true|none||none|
|» permissions|object|true|none||none|
|»» project_access|object|true|none||none|
|»»» access_level|integer|true|none||none|
|»»» notification_level|integer|true|none||none|
|»» group_access|null|true|none||none|

## POST 项目远程导入

POST /api/v4/projects

> Body 请求参数

```json
{
  "name": "hdq-remote-import",
  "path": "hdq-remote-import",
  "import_url": "http://10.11.2.101:8082/quick-demo/abc.git",
  "initialize_with_readme": false
}
```

### 请求参数

|名称|位置|类型|必选|说明|
|---|---|---|---|---|
|Authorization|header|string| 否 |none|
|body|body|object| 否 |none|

> 返回示例

> 200 Response

```json
{}
```

### 返回结果

|状态码|状态码含义|说明|数据模型|
|---|---|---|---|
|200|[OK](https://tools.ietf.org/html/rfc7231#section-6.3.1)|成功|Inline|

### 返回数据结构

## GET 获取指定项目成员

GET /api/v4/projects/{id}/members

### 请求参数

|名称|位置|类型|必选|说明|
|---|---|---|---|---|
|id|path|string| 是 |none|
|Authorization|header|string| 否 |none|
|Content-Type|header|string| 否 |none|

> 返回示例

> 成功

```json
[
  {
    "access_level": 50,
    "created_at": "2023-06-29T08:25:35.837Z",
    "created_by": {
      "id": 14948797,
      "username": "hdengquan4",
      "name": "dengquan huang",
      "state": "active",
      "avatar_url": "https://secure.gravatar.com/avatar/cc08dd76f76291e2b806cbe3f21b32ac?s=80&d=identicon",
      "web_url": "https://gitlab.com/hdengquan4"
    },
    "expires_at": null,
    "id": 14948797,
    "username": "hdengquan4",
    "name": "dengquan huang",
    "state": "active",
    "avatar_url": "https://secure.gravatar.com/avatar/cc08dd76f76291e2b806cbe3f21b32ac?s=80&d=identicon",
    "web_url": "https://gitlab.com/hdengquan4",
    "membership_state": "active"
  }
]
```

### 返回结果

|状态码|状态码含义|说明|数据模型|
|---|---|---|---|
|200|[OK](https://tools.ietf.org/html/rfc7231#section-6.3.1)|成功|Inline|

### 返回数据结构

状态码 **200**

|名称|类型|必选|约束|中文名|说明|
|---|---|---|---|---|---|
|» access_level|integer|false|none||none|
|» created_at|string|false|none||none|
|» created_by|object|false|none||none|
|»» id|integer|true|none||none|
|»» username|string|true|none||none|
|»» name|string|true|none||none|
|»» state|string|true|none||none|
|»» avatar_url|string|true|none||none|
|»» web_url|string|true|none||none|
|» expires_at|null|false|none||none|
|» id|integer|false|none||none|
|» username|string|false|none||none|
|» name|string|false|none||none|
|» state|string|false|none||none|
|» avatar_url|string|false|none||none|
|» web_url|string|false|none||none|
|» membership_state|string|false|none||none|

## GET 获取指定项目成员 Copy

GET /api/v4/projects/{id}/repository/branches/{branch}

### 请求参数

|名称|位置|类型|必选|说明|
|---|---|---|---|---|
|id|path|integer| 是 |none|
|branch|path|string| 是 |none|
|Authorization|header|string| 否 |none|
|Content-Type|header|string| 否 |none|

> 返回示例

> 成功

```json
[
  {
    "access_level": 50,
    "created_at": "2023-06-29T08:25:35.837Z",
    "created_by": {
      "id": 14948797,
      "username": "hdengquan4",
      "name": "dengquan huang",
      "state": "active",
      "avatar_url": "https://secure.gravatar.com/avatar/cc08dd76f76291e2b806cbe3f21b32ac?s=80&d=identicon",
      "web_url": "https://gitlab.com/hdengquan4"
    },
    "expires_at": null,
    "id": 14948797,
    "username": "hdengquan4",
    "name": "dengquan huang",
    "state": "active",
    "avatar_url": "https://secure.gravatar.com/avatar/cc08dd76f76291e2b806cbe3f21b32ac?s=80&d=identicon",
    "web_url": "https://gitlab.com/hdengquan4",
    "membership_state": "active"
  }
]
```

### 返回结果

|状态码|状态码含义|说明|数据模型|
|---|---|---|---|
|200|[OK](https://tools.ietf.org/html/rfc7231#section-6.3.1)|成功|Inline|

### 返回数据结构

状态码 **200**

|名称|类型|必选|约束|中文名|说明|
|---|---|---|---|---|---|
|» access_level|integer|false|none||none|
|» created_at|string|false|none||none|
|» created_by|object|false|none||none|
|»» id|integer|true|none||none|
|»» username|string|true|none||none|
|»» name|string|true|none||none|
|»» state|string|true|none||none|
|»» avatar_url|string|true|none||none|
|»» web_url|string|true|none||none|
|» expires_at|null|false|none||none|
|» id|integer|false|none||none|
|» username|string|false|none||none|
|» name|string|false|none||none|
|» state|string|false|none||none|
|» avatar_url|string|false|none||none|
|» web_url|string|false|none||none|
|» membership_state|string|false|none||none|

## POST 上传文件

POST /api/v4/projects/1/uploads

> Body 请求参数

```yaml
file: string

```

### 请求参数

|名称|位置|类型|必选|说明|
|---|---|---|---|---|
|Authorization|header|string| 否 |none|
|body|body|object| 否 |none|
|» file|body|string(binary)| 是 |none|

> 返回示例

> 200 Response

```json
{}
```

### 返回结果

|状态码|状态码含义|说明|数据模型|
|---|---|---|---|
|200|[OK](https://tools.ietf.org/html/rfc7231#section-6.3.1)|成功|Inline|

### 返回数据结构

## POST 项目导入

POST /api/v4/projects/import

> Body 请求参数

```yaml
file: file:///Users/huangdq/projects/java/demos/aopDemo.zip
namespace: "833"
path: hdq-import-test

```

### 请求参数

|名称|位置|类型|必选|说明|
|---|---|---|---|---|
|Authorization|header|string| 否 |none|
|body|body|object| 否 |none|
|» file|body|string(binary)| 是 |none|
|» namespace|body|string| 否 |none|
|» path|body|string| 否 |none|

> 返回示例

> 200 Response

```json
{}
```

### 返回结果

|状态码|状态码含义|说明|数据模型|
|---|---|---|---|
|200|[OK](https://tools.ietf.org/html/rfc7231#section-6.3.1)|成功|Inline|

### 返回数据结构

# users

## GET 列出所有用户

GET /api/v4/users

### 请求参数

|名称|位置|类型|必选|说明|
|---|---|---|---|---|
|username|query|string| 否 |none|
|Authorization|header|string| 否 |none|
|Content-Type|header|string| 否 |none|

> 返回示例

> 200 Response

```json
{}
```

### 返回结果

|状态码|状态码含义|说明|数据模型|
|---|---|---|---|
|200|[OK](https://tools.ietf.org/html/rfc7231#section-6.3.1)|成功|Inline|

### 返回数据结构

## POST 创建用户

POST /api/v4/users

> Body 请求参数

```json
{
  "email": "1738945232@qq.com",
  "name": "hdq_test",
  "username": "hdq_test"
}
```

### 请求参数

|名称|位置|类型|必选|说明|
|---|---|---|---|---|
|Authorization|header|string| 否 |none|
|Content-Type|header|string| 否 |none|
|body|body|object| 否 |none|
|» email|body|string| 是 |none|
|» name|body|string| 是 |none|
|» username|body|string| 是 |none|

> 返回示例

> 200 Response

```json
{}
```

### 返回结果

|状态码|状态码含义|说明|数据模型|
|---|---|---|---|
|200|[OK](https://tools.ietf.org/html/rfc7231#section-6.3.1)|成功|Inline|

### 返回数据结构

## POST 创建个人访问令牌

POST /api/v4/users/7/personal_access_tokens

> Body 请求参数

```json
{
  "name": "1738945230@qq.com",
  "scopes": [
    "api",
    "write_repository",
    "write_registry"
  ]
}
```

### 请求参数

|名称|位置|类型|必选|说明|
|---|---|---|---|---|
|Authorization|header|string| 否 |none|
|Content-Type|header|string| 否 |none|
|body|body|object| 否 |none|

> 返回示例

> 200 Response

```json
{}
```

### 返回结果

|状态码|状态码含义|说明|数据模型|
|---|---|---|---|
|200|[OK](https://tools.ietf.org/html/rfc7231#section-6.3.1)|成功|Inline|

### 返回数据结构

## POST 创建ssh 密钥

POST /api/v4/users/7/keys

> Body 请求参数

```json
{
  "name": "1738945230@qq.com",
  "scopes": [
    "api",
    "write_repository",
    "write_registry"
  ]
}
```

### 请求参数

|名称|位置|类型|必选|说明|
|---|---|---|---|---|
|Authorization|header|string| 否 |none|
|Content-Type|header|string| 否 |none|
|body|body|object| 否 |none|

> 返回示例

> 200 Response

```json
{}
```

### 返回结果

|状态码|状态码含义|说明|数据模型|
|---|---|---|---|
|200|[OK](https://tools.ietf.org/html/rfc7231#section-6.3.1)|成功|Inline|

### 返回数据结构

## GET 获取指定用户

GET /api/v4/users/14948797

### 请求参数

|名称|位置|类型|必选|说明|
|---|---|---|---|---|
|Authorization|header|string| 否 |none|
|Content-Type|header|string| 否 |none|

> 返回示例

> 200 Response

```json
{}
```

### 返回结果

|状态码|状态码含义|说明|数据模型|
|---|---|---|---|
|200|[OK](https://tools.ietf.org/html/rfc7231#section-6.3.1)|成功|Inline|

### 返回数据结构

## GET 获取指定用户所有项目

GET /api/v4/users/{user_id}/projects

### 请求参数

|名称|位置|类型|必选|说明|
|---|---|---|---|---|
|user_id|path|string| 是 |none|
|Authorization|header|string| 否 |none|
|Content-Type|header|string| 否 |none|

> 返回示例

> 成功

```json
[
  {
    "id": 47261069,
    "description": "这是个接口测试创建项目的接口",
    "name": "hdq_test",
    "name_with_namespace": "dengquan huang / hdq_test",
    "path": "hdq_test",
    "path_with_namespace": "hdengquan4/hdq_test",
    "created_at": "2023-06-29T08:25:35.482Z",
    "default_branch": "main",
    "tag_list": [],
    "topics": [],
    "ssh_url_to_repo": "git@gitlab.com:hdengquan4/hdq_test.git",
    "http_url_to_repo": "https://gitlab.com/hdengquan4/hdq_test.git",
    "web_url": "https://gitlab.com/hdengquan4/hdq_test",
    "readme_url": "https://gitlab.com/hdengquan4/hdq_test/-/blob/main/README.md",
    "forks_count": 0,
    "avatar_url": null,
    "star_count": 0,
    "last_activity_at": "2023-06-29T08:25:35.482Z",
    "namespace": {
      "id": 69277559,
      "name": "dengquan huang",
      "path": "hdengquan4",
      "kind": "user",
      "full_path": "hdengquan4",
      "parent_id": null,
      "avatar_url": "https://secure.gravatar.com/avatar/cc08dd76f76291e2b806cbe3f21b32ac?s=80&d=identicon",
      "web_url": "https://gitlab.com/hdengquan4"
    },
    "container_registry_image_prefix": "registry.gitlab.com/hdengquan4/hdq_test",
    "_links": {
      "self": "https://gitlab.com/api/v4/projects/47261069",
      "issues": "https://gitlab.com/api/v4/projects/47261069/issues",
      "merge_requests": "https://gitlab.com/api/v4/projects/47261069/merge_requests",
      "repo_branches": "https://gitlab.com/api/v4/projects/47261069/repository/branches",
      "labels": "https://gitlab.com/api/v4/projects/47261069/labels",
      "events": "https://gitlab.com/api/v4/projects/47261069/events",
      "members": "https://gitlab.com/api/v4/projects/47261069/members",
      "cluster_agents": "https://gitlab.com/api/v4/projects/47261069/cluster_agents"
    },
    "packages_enabled": true,
    "empty_repo": false,
    "archived": false,
    "visibility": "private",
    "owner": {
      "id": 14948797,
      "username": "hdengquan4",
      "name": "dengquan huang",
      "state": "active",
      "avatar_url": "https://secure.gravatar.com/avatar/cc08dd76f76291e2b806cbe3f21b32ac?s=80&d=identicon",
      "web_url": "https://gitlab.com/hdengquan4"
    },
    "resolve_outdated_diff_discussions": false,
    "container_expiration_policy": {
      "cadence": "1d",
      "enabled": false,
      "keep_n": 10,
      "older_than": "90d",
      "name_regex": ".*",
      "name_regex_keep": null,
      "next_run_at": "2023-06-30T08:25:35.519Z"
    },
    "issues_enabled": true,
    "merge_requests_enabled": true,
    "wiki_enabled": true,
    "jobs_enabled": true,
    "snippets_enabled": true,
    "container_registry_enabled": true,
    "service_desk_enabled": true,
    "service_desk_address": "contact-project+hdengquan4-hdq-test-47261069-issue-@incoming.gitlab.com",
    "can_create_merge_request_in": true,
    "issues_access_level": "enabled",
    "repository_access_level": "enabled",
    "merge_requests_access_level": "enabled",
    "forking_access_level": "enabled",
    "wiki_access_level": "enabled",
    "builds_access_level": "enabled",
    "snippets_access_level": "enabled",
    "pages_access_level": "private",
    "analytics_access_level": "enabled",
    "container_registry_access_level": "enabled",
    "security_and_compliance_access_level": "private",
    "releases_access_level": "enabled",
    "environments_access_level": "enabled",
    "feature_flags_access_level": "enabled",
    "infrastructure_access_level": "enabled",
    "monitor_access_level": "enabled",
    "emails_disabled": null,
    "shared_runners_enabled": true,
    "lfs_enabled": true,
    "creator_id": 14948797,
    "import_url": null,
    "import_type": null,
    "import_status": "none",
    "open_issues_count": 0,
    "description_html": "<p data-sourcepos=\"1:1-1:42\" dir=\"auto\">这是个接口测试创建项目的接口</p>",
    "updated_at": "2023-06-29T08:25:36.435Z",
    "ci_default_git_depth": 20,
    "ci_forward_deployment_enabled": true,
    "ci_job_token_scope_enabled": false,
    "ci_separated_caches": true,
    "ci_allow_fork_pipelines_to_run_in_parent_project": true,
    "build_git_strategy": "fetch",
    "keep_latest_artifact": true,
    "restrict_user_defined_variables": false,
    "runners_token": "GR13489415m_RkCywW-D16MtzKVCp",
    "runner_token_expiration_interval": null,
    "group_runners_enabled": true,
    "auto_cancel_pending_pipelines": "enabled",
    "build_timeout": 3600,
    "auto_devops_enabled": false,
    "auto_devops_deploy_strategy": "continuous",
    "ci_config_path": "",
    "public_jobs": true,
    "shared_with_groups": [],
    "only_allow_merge_if_pipeline_succeeds": false,
    "allow_merge_on_skipped_pipeline": null,
    "request_access_enabled": true,
    "only_allow_merge_if_all_discussions_are_resolved": false,
    "remove_source_branch_after_merge": true,
    "printing_merge_request_link_enabled": true,
    "merge_method": "merge",
    "squash_option": "default_off",
    "enforce_auth_checks_on_uploads": true,
    "suggestion_commit_message": null,
    "merge_commit_template": null,
    "squash_commit_template": null,
    "issue_branch_template": null,
    "autoclose_referenced_issues": true,
    "external_authorization_classification_label": "",
    "requirements_enabled": false,
    "requirements_access_level": "enabled",
    "security_and_compliance_enabled": true,
    "compliance_frameworks": [],
    "permissions": {
      "project_access": {
        "access_level": 50,
        "notification_level": 3
      },
      "group_access": null
    }
  }
]
```

### 返回结果

|状态码|状态码含义|说明|数据模型|
|---|---|---|---|
|200|[OK](https://tools.ietf.org/html/rfc7231#section-6.3.1)|成功|Inline|

### 返回数据结构

状态码 **200**

|名称|类型|必选|约束|中文名|说明|
|---|---|---|---|---|---|
|» id|integer|false|none||none|
|» description|string|false|none||none|
|» name|string|false|none||none|
|» name_with_namespace|string|false|none||none|
|» path|string|false|none||none|
|» path_with_namespace|string|false|none||none|
|» created_at|string|false|none||none|
|» default_branch|string|false|none||none|
|» tag_list|[string]|false|none||none|
|» topics|[string]|false|none||none|
|» ssh_url_to_repo|string|false|none||none|
|» http_url_to_repo|string|false|none||none|
|» web_url|string|false|none||none|
|» readme_url|string|false|none||none|
|» forks_count|integer|false|none||none|
|» avatar_url|null|false|none||none|
|» star_count|integer|false|none||none|
|» last_activity_at|string|false|none||none|
|» namespace|object|false|none||none|
|»» id|integer|true|none||none|
|»» name|string|true|none||none|
|»» path|string|true|none||none|
|»» kind|string|true|none||none|
|»» full_path|string|true|none||none|
|»» parent_id|null|true|none||none|
|»» avatar_url|string|true|none||none|
|»» web_url|string|true|none||none|
|» container_registry_image_prefix|string|false|none||none|
|» _links|object|false|none||none|
|»» self|string|true|none||none|
|»» issues|string|true|none||none|
|»» merge_requests|string|true|none||none|
|»» repo_branches|string|true|none||none|
|»» labels|string|true|none||none|
|»» events|string|true|none||none|
|»» members|string|true|none||none|
|»» cluster_agents|string|true|none||none|
|» packages_enabled|boolean|false|none||none|
|» empty_repo|boolean|false|none||none|
|» archived|boolean|false|none||none|
|» visibility|string|false|none||none|
|» owner|object|false|none||none|
|»» id|integer|true|none||none|
|»» username|string|true|none||none|
|»» name|string|true|none||none|
|»» state|string|true|none||none|
|»» avatar_url|string|true|none||none|
|»» web_url|string|true|none||none|
|» resolve_outdated_diff_discussions|boolean|false|none||none|
|» container_expiration_policy|object|false|none||none|
|»» cadence|string|true|none||none|
|»» enabled|boolean|true|none||none|
|»» keep_n|integer|true|none||none|
|»» older_than|string|true|none||none|
|»» name_regex|string|true|none||none|
|»» name_regex_keep|null|true|none||none|
|»» next_run_at|string|true|none||none|
|» issues_enabled|boolean|false|none||none|
|» merge_requests_enabled|boolean|false|none||none|
|» wiki_enabled|boolean|false|none||none|
|» jobs_enabled|boolean|false|none||none|
|» snippets_enabled|boolean|false|none||none|
|» container_registry_enabled|boolean|false|none||none|
|» service_desk_enabled|boolean|false|none||none|
|» service_desk_address|string|false|none||none|
|» can_create_merge_request_in|boolean|false|none||none|
|» issues_access_level|string|false|none||none|
|» repository_access_level|string|false|none||none|
|» merge_requests_access_level|string|false|none||none|
|» forking_access_level|string|false|none||none|
|» wiki_access_level|string|false|none||none|
|» builds_access_level|string|false|none||none|
|» snippets_access_level|string|false|none||none|
|» pages_access_level|string|false|none||none|
|» analytics_access_level|string|false|none||none|
|» container_registry_access_level|string|false|none||none|
|» security_and_compliance_access_level|string|false|none||none|
|» releases_access_level|string|false|none||none|
|» environments_access_level|string|false|none||none|
|» feature_flags_access_level|string|false|none||none|
|» infrastructure_access_level|string|false|none||none|
|» monitor_access_level|string|false|none||none|
|» emails_disabled|null|false|none||none|
|» shared_runners_enabled|boolean|false|none||none|
|» lfs_enabled|boolean|false|none||none|
|» creator_id|integer|false|none||none|
|» import_url|null|false|none||none|
|» import_type|null|false|none||none|
|» import_status|string|false|none||none|
|» open_issues_count|integer|false|none||none|
|» description_html|string|false|none||none|
|» updated_at|string|false|none||none|
|» ci_default_git_depth|integer|false|none||none|
|» ci_forward_deployment_enabled|boolean|false|none||none|
|» ci_job_token_scope_enabled|boolean|false|none||none|
|» ci_separated_caches|boolean|false|none||none|
|» ci_allow_fork_pipelines_to_run_in_parent_project|boolean|false|none||none|
|» build_git_strategy|string|false|none||none|
|» keep_latest_artifact|boolean|false|none||none|
|» restrict_user_defined_variables|boolean|false|none||none|
|» runners_token|string|false|none||none|
|» runner_token_expiration_interval|null|false|none||none|
|» group_runners_enabled|boolean|false|none||none|
|» auto_cancel_pending_pipelines|string|false|none||none|
|» build_timeout|integer|false|none||none|
|» auto_devops_enabled|boolean|false|none||none|
|» auto_devops_deploy_strategy|string|false|none||none|
|» ci_config_path|string|false|none||none|
|» public_jobs|boolean|false|none||none|
|» shared_with_groups|[string]|false|none||none|
|» only_allow_merge_if_pipeline_succeeds|boolean|false|none||none|
|» allow_merge_on_skipped_pipeline|null|false|none||none|
|» request_access_enabled|boolean|false|none||none|
|» only_allow_merge_if_all_discussions_are_resolved|boolean|false|none||none|
|» remove_source_branch_after_merge|boolean|false|none||none|
|» printing_merge_request_link_enabled|boolean|false|none||none|
|» merge_method|string|false|none||none|
|» squash_option|string|false|none||none|
|» enforce_auth_checks_on_uploads|boolean|false|none||none|
|» suggestion_commit_message|null|false|none||none|
|» merge_commit_template|null|false|none||none|
|» squash_commit_template|null|false|none||none|
|» issue_branch_template|null|false|none||none|
|» autoclose_referenced_issues|boolean|false|none||none|
|» external_authorization_classification_label|string|false|none||none|
|» requirements_enabled|boolean|false|none||none|
|» requirements_access_level|string|false|none||none|
|» security_and_compliance_enabled|boolean|false|none||none|
|» compliance_frameworks|[string]|false|none||none|
|» permissions|object|false|none||none|
|»» project_access|object|true|none||none|
|»»» access_level|integer|true|none||none|
|»»» notification_level|integer|true|none||none|
|»» group_access|null|true|none||none|

# groups

## GET 列出所有群组

GET /api/v4/groups

### 请求参数

|名称|位置|类型|必选|说明|
|---|---|---|---|---|
|page|query|integer| 否 |none|
|per_page|query|integer| 否 |none|
|Authorization|header|string| 否 |none|
|Content-Type|header|string| 否 |none|

> 返回示例

> 200 Response

```json
{}
```

### 返回结果

|状态码|状态码含义|说明|数据模型|
|---|---|---|---|
|200|[OK](https://tools.ietf.org/html/rfc7231#section-6.3.1)|成功|Inline|

### 返回数据结构

## POST 新建群组

POST /api/v4/groups

> Body 请求参数

```json
{
  "name": "group_test",
  "path": ""
}
```

### 请求参数

|名称|位置|类型|必选|说明|
|---|---|---|---|---|
|body|body|object| 否 |none|

> 返回示例

> 200 Response

```json
{}
```

### 返回结果

|状态码|状态码含义|说明|数据模型|
|---|---|---|---|
|200|[OK](https://tools.ietf.org/html/rfc7231#section-6.3.1)|成功|Inline|

### 返回数据结构

## GET 获取指定群组信息

GET /api/v4/groups/{id}

### 请求参数

|名称|位置|类型|必选|说明|
|---|---|---|---|---|
|id|path|string| 是 |none|
|Authorization|header|string| 否 |none|
|Content-Type|header|string| 否 |none|

> 返回示例

> 成功

```json
{
  "id": 69460672,
  "web_url": "https://gitlab.com/groups/hdq_team",
  "name": "hdq_team",
  "path": "hdq_team",
  "description": "",
  "visibility": "private",
  "share_with_group_lock": false,
  "require_two_factor_authentication": false,
  "two_factor_grace_period": 48,
  "project_creation_level": "developer",
  "auto_devops_enabled": null,
  "subgroup_creation_level": "maintainer",
  "emails_disabled": null,
  "mentions_disabled": null,
  "lfs_enabled": true,
  "default_branch_protection": 2,
  "avatar_url": null,
  "request_access_enabled": true,
  "full_name": "hdq_team",
  "full_path": "hdq_team",
  "created_at": "2023-06-29T08:50:34.125Z",
  "parent_id": null,
  "ldap_cn": null,
  "ldap_access": null,
  "wiki_access_level": "enabled",
  "shared_with_groups": [],
  "runners_token": "GR1348941Nvu3nxFsmxzuPtu7ZYwg",
  "prevent_sharing_groups_outside_hierarchy": false,
  "projects": [
    {
      "id": 47262086,
      "description": "这是个测试创建群组项目的接口",
      "name": "hdq_team_test",
      "name_with_namespace": "hdq_team / hdq_team_test",
      "path": "hdq_team_test",
      "path_with_namespace": "hdq_team/hdq_team_test",
      "created_at": "2023-06-29T08:58:15.958Z",
      "default_branch": "main",
      "tag_list": [],
      "topics": [],
      "ssh_url_to_repo": "git@gitlab.com:hdq_team/hdq_team_test.git",
      "http_url_to_repo": "https://gitlab.com/hdq_team/hdq_team_test.git",
      "web_url": "https://gitlab.com/hdq_team/hdq_team_test",
      "readme_url": "https://gitlab.com/hdq_team/hdq_team_test/-/blob/main/README.md",
      "forks_count": 0,
      "avatar_url": null,
      "star_count": 0,
      "last_activity_at": "2023-06-29T08:58:15.958Z",
      "namespace": {
        "id": 69460672,
        "name": "hdq_team",
        "path": "hdq_team",
        "kind": "group",
        "full_path": "hdq_team",
        "parent_id": null,
        "avatar_url": null,
        "web_url": "https://gitlab.com/groups/hdq_team"
      },
      "container_registry_image_prefix": "registry.gitlab.com/hdq_team/hdq_team_test",
      "_links": {
        "self": "https://gitlab.com/api/v4/projects/47262086",
        "issues": "https://gitlab.com/api/v4/projects/47262086/issues",
        "merge_requests": "https://gitlab.com/api/v4/projects/47262086/merge_requests",
        "repo_branches": "https://gitlab.com/api/v4/projects/47262086/repository/branches",
        "labels": "https://gitlab.com/api/v4/projects/47262086/labels",
        "events": "https://gitlab.com/api/v4/projects/47262086/events",
        "members": "https://gitlab.com/api/v4/projects/47262086/members",
        "cluster_agents": "https://gitlab.com/api/v4/projects/47262086/cluster_agents"
      },
      "packages_enabled": true,
      "empty_repo": false,
      "archived": false,
      "visibility": "private",
      "resolve_outdated_diff_discussions": false,
      "container_expiration_policy": {
        "cadence": "1d",
        "enabled": false,
        "keep_n": 10,
        "older_than": "90d",
        "name_regex": ".*",
        "name_regex_keep": null,
        "next_run_at": "2023-06-30T08:58:15.997Z"
      },
      "issues_enabled": true,
      "merge_requests_enabled": true,
      "wiki_enabled": true,
      "jobs_enabled": true,
      "snippets_enabled": true,
      "container_registry_enabled": true,
      "service_desk_enabled": true,
      "service_desk_address": "contact-project+hdq-team-hdq-team-test-47262086-issue-@incoming.gitlab.com",
      "can_create_merge_request_in": true,
      "issues_access_level": "enabled",
      "repository_access_level": "enabled",
      "merge_requests_access_level": "enabled",
      "forking_access_level": "enabled",
      "wiki_access_level": "enabled",
      "builds_access_level": "enabled",
      "snippets_access_level": "enabled",
      "pages_access_level": "private",
      "analytics_access_level": "enabled",
      "container_registry_access_level": "enabled",
      "security_and_compliance_access_level": "private",
      "releases_access_level": "enabled",
      "environments_access_level": "enabled",
      "feature_flags_access_level": "enabled",
      "infrastructure_access_level": "enabled",
      "monitor_access_level": "enabled",
      "emails_disabled": null,
      "shared_runners_enabled": true,
      "lfs_enabled": true,
      "creator_id": 14948797,
      "import_url": null,
      "import_type": null,
      "import_status": "none",
      "open_issues_count": 0,
      "description_html": "<p data-sourcepos=\"1:1-1:42\" dir=\"auto\">这是个测试创建群组项目的接口</p>",
      "updated_at": "2023-06-29T09:20:04.326Z",
      "ci_default_git_depth": 20,
      "ci_forward_deployment_enabled": true,
      "ci_job_token_scope_enabled": false,
      "ci_separated_caches": true,
      "ci_allow_fork_pipelines_to_run_in_parent_project": true,
      "build_git_strategy": "fetch",
      "keep_latest_artifact": true,
      "restrict_user_defined_variables": false,
      "runners_token": "GR1348941vC6q1RuAygmfxB168yBy",
      "runner_token_expiration_interval": null,
      "group_runners_enabled": true,
      "auto_cancel_pending_pipelines": "enabled",
      "build_timeout": 3600,
      "auto_devops_enabled": false,
      "auto_devops_deploy_strategy": "continuous",
      "ci_config_path": "",
      "public_jobs": true,
      "shared_with_groups": [],
      "only_allow_merge_if_pipeline_succeeds": false,
      "allow_merge_on_skipped_pipeline": null,
      "request_access_enabled": true,
      "only_allow_merge_if_all_discussions_are_resolved": false,
      "remove_source_branch_after_merge": true,
      "printing_merge_request_link_enabled": true,
      "merge_method": "merge",
      "squash_option": "default_off",
      "enforce_auth_checks_on_uploads": true,
      "suggestion_commit_message": null,
      "merge_commit_template": null,
      "squash_commit_template": null,
      "issue_branch_template": null,
      "autoclose_referenced_issues": true,
      "external_authorization_classification_label": "",
      "requirements_enabled": false,
      "requirements_access_level": "enabled",
      "security_and_compliance_enabled": true,
      "compliance_frameworks": []
    }
  ],
  "shared_projects": [],
  "shared_runners_minutes_limit": null,
  "extra_shared_runners_minutes_limit": null,
  "prevent_forking_outside_group": null,
  "membership_lock": false
}
```

### 返回结果

|状态码|状态码含义|说明|数据模型|
|---|---|---|---|
|200|[OK](https://tools.ietf.org/html/rfc7231#section-6.3.1)|成功|Inline|

### 返回数据结构

状态码 **200**

|名称|类型|必选|约束|中文名|说明|
|---|---|---|---|---|---|
|» id|integer|true|none||none|
|» web_url|string|true|none||none|
|» name|string|true|none||none|
|» path|string|true|none||none|
|» description|string|true|none||none|
|» visibility|string|true|none||none|
|» share_with_group_lock|boolean|true|none||none|
|» require_two_factor_authentication|boolean|true|none||none|
|» two_factor_grace_period|integer|true|none||none|
|» project_creation_level|string|true|none||none|
|» auto_devops_enabled|null|true|none||none|
|» subgroup_creation_level|string|true|none||none|
|» emails_disabled|null|true|none||none|
|» mentions_disabled|null|true|none||none|
|» lfs_enabled|boolean|true|none||none|
|» default_branch_protection|integer|true|none||none|
|» avatar_url|null|true|none||none|
|» request_access_enabled|boolean|true|none||none|
|» full_name|string|true|none||none|
|» full_path|string|true|none||none|
|» created_at|string|true|none||none|
|» parent_id|null|true|none||none|
|» ldap_cn|null|true|none||none|
|» ldap_access|null|true|none||none|
|» wiki_access_level|string|true|none||none|
|» shared_with_groups|[string]|true|none||none|
|» runners_token|string|true|none||none|
|» prevent_sharing_groups_outside_hierarchy|boolean|true|none||none|
|» projects|[object]|true|none||none|
|»» id|integer|false|none||none|
|»» description|string|false|none||none|
|»» name|string|false|none||none|
|»» name_with_namespace|string|false|none||none|
|»» path|string|false|none||none|
|»» path_with_namespace|string|false|none||none|
|»» created_at|string|false|none||none|
|»» default_branch|string|false|none||none|
|»» tag_list|[string]|false|none||none|
|»» topics|[string]|false|none||none|
|»» ssh_url_to_repo|string|false|none||none|
|»» http_url_to_repo|string|false|none||none|
|»» web_url|string|false|none||none|
|»» readme_url|string|false|none||none|
|»» forks_count|integer|false|none||none|
|»» avatar_url|null|false|none||none|
|»» star_count|integer|false|none||none|
|»» last_activity_at|string|false|none||none|
|»» namespace|object|false|none||none|
|»»» id|integer|true|none||none|
|»»» name|string|true|none||none|
|»»» path|string|true|none||none|
|»»» kind|string|true|none||none|
|»»» full_path|string|true|none||none|
|»»» parent_id|null|true|none||none|
|»»» avatar_url|null|true|none||none|
|»»» web_url|string|true|none||none|
|»» container_registry_image_prefix|string|false|none||none|
|»» _links|object|false|none||none|
|»»» self|string|true|none||none|
|»»» issues|string|true|none||none|
|»»» merge_requests|string|true|none||none|
|»»» repo_branches|string|true|none||none|
|»»» labels|string|true|none||none|
|»»» events|string|true|none||none|
|»»» members|string|true|none||none|
|»»» cluster_agents|string|true|none||none|
|»» packages_enabled|boolean|false|none||none|
|»» empty_repo|boolean|false|none||none|
|»» archived|boolean|false|none||none|
|»» visibility|string|false|none||none|
|»» resolve_outdated_diff_discussions|boolean|false|none||none|
|»» container_expiration_policy|object|false|none||none|
|»»» cadence|string|true|none||none|
|»»» enabled|boolean|true|none||none|
|»»» keep_n|integer|true|none||none|
|»»» older_than|string|true|none||none|
|»»» name_regex|string|true|none||none|
|»»» name_regex_keep|null|true|none||none|
|»»» next_run_at|string|true|none||none|
|»» issues_enabled|boolean|false|none||none|
|»» merge_requests_enabled|boolean|false|none||none|
|»» wiki_enabled|boolean|false|none||none|
|»» jobs_enabled|boolean|false|none||none|
|»» snippets_enabled|boolean|false|none||none|
|»» container_registry_enabled|boolean|false|none||none|
|»» service_desk_enabled|boolean|false|none||none|
|»» service_desk_address|string|false|none||none|
|»» can_create_merge_request_in|boolean|false|none||none|
|»» issues_access_level|string|false|none||none|
|»» repository_access_level|string|false|none||none|
|»» merge_requests_access_level|string|false|none||none|
|»» forking_access_level|string|false|none||none|
|»» wiki_access_level|string|false|none||none|
|»» builds_access_level|string|false|none||none|
|»» snippets_access_level|string|false|none||none|
|»» pages_access_level|string|false|none||none|
|»» analytics_access_level|string|false|none||none|
|»» container_registry_access_level|string|false|none||none|
|»» security_and_compliance_access_level|string|false|none||none|
|»» releases_access_level|string|false|none||none|
|»» environments_access_level|string|false|none||none|
|»» feature_flags_access_level|string|false|none||none|
|»» infrastructure_access_level|string|false|none||none|
|»» monitor_access_level|string|false|none||none|
|»» emails_disabled|null|false|none||none|
|»» shared_runners_enabled|boolean|false|none||none|
|»» lfs_enabled|boolean|false|none||none|
|»» creator_id|integer|false|none||none|
|»» import_url|null|false|none||none|
|»» import_type|null|false|none||none|
|»» import_status|string|false|none||none|
|»» open_issues_count|integer|false|none||none|
|»» description_html|string|false|none||none|
|»» updated_at|string|false|none||none|
|»» ci_default_git_depth|integer|false|none||none|
|»» ci_forward_deployment_enabled|boolean|false|none||none|
|»» ci_job_token_scope_enabled|boolean|false|none||none|
|»» ci_separated_caches|boolean|false|none||none|
|»» ci_allow_fork_pipelines_to_run_in_parent_project|boolean|false|none||none|
|»» build_git_strategy|string|false|none||none|
|»» keep_latest_artifact|boolean|false|none||none|
|»» restrict_user_defined_variables|boolean|false|none||none|
|»» runners_token|string|false|none||none|
|»» runner_token_expiration_interval|null|false|none||none|
|»» group_runners_enabled|boolean|false|none||none|
|»» auto_cancel_pending_pipelines|string|false|none||none|
|»» build_timeout|integer|false|none||none|
|»» auto_devops_enabled|boolean|false|none||none|
|»» auto_devops_deploy_strategy|string|false|none||none|
|»» ci_config_path|string|false|none||none|
|»» public_jobs|boolean|false|none||none|
|»» shared_with_groups|[string]|false|none||none|
|»» only_allow_merge_if_pipeline_succeeds|boolean|false|none||none|
|»» allow_merge_on_skipped_pipeline|null|false|none||none|
|»» request_access_enabled|boolean|false|none||none|
|»» only_allow_merge_if_all_discussions_are_resolved|boolean|false|none||none|
|»» remove_source_branch_after_merge|boolean|false|none||none|
|»» printing_merge_request_link_enabled|boolean|false|none||none|
|»» merge_method|string|false|none||none|
|»» squash_option|string|false|none||none|
|»» enforce_auth_checks_on_uploads|boolean|false|none||none|
|»» suggestion_commit_message|null|false|none||none|
|»» merge_commit_template|null|false|none||none|
|»» squash_commit_template|null|false|none||none|
|»» issue_branch_template|null|false|none||none|
|»» autoclose_referenced_issues|boolean|false|none||none|
|»» external_authorization_classification_label|string|false|none||none|
|»» requirements_enabled|boolean|false|none||none|
|»» requirements_access_level|string|false|none||none|
|»» security_and_compliance_enabled|boolean|false|none||none|
|»» compliance_frameworks|[string]|false|none||none|
|» shared_projects|[string]|true|none||none|
|» shared_runners_minutes_limit|null|true|none||none|
|» extra_shared_runners_minutes_limit|null|true|none||none|
|» prevent_forking_outside_group|null|true|none||none|
|» membership_lock|boolean|true|none||none|

## GET 获取指定群组成员信息

GET /api/v4/groups/{id}/members

### 请求参数

|名称|位置|类型|必选|说明|
|---|---|---|---|---|
|id|path|string| 是 |none|
|Authorization|header|string| 否 |none|
|Content-Type|header|string| 否 |none|

> 返回示例

> 成功

```json
[
  {
    "access_level": 50,
    "created_at": "2023-06-29T08:50:34.252Z",
    "expires_at": null,
    "id": 14948797,
    "username": "hdengquan4",
    "name": "dengquan huang",
    "state": "active",
    "avatar_url": "https://secure.gravatar.com/avatar/cc08dd76f76291e2b806cbe3f21b32ac?s=80&d=identicon",
    "web_url": "https://gitlab.com/hdengquan4",
    "membership_state": "active"
  }
]
```

### 返回结果

|状态码|状态码含义|说明|数据模型|
|---|---|---|---|
|200|[OK](https://tools.ietf.org/html/rfc7231#section-6.3.1)|成功|Inline|

### 返回数据结构

状态码 **200**

|名称|类型|必选|约束|中文名|说明|
|---|---|---|---|---|---|
|» access_level|integer|false|none||none|
|» created_at|string|false|none||none|
|» expires_at|null|false|none||none|
|» id|integer|false|none||none|
|» username|string|false|none||none|
|» name|string|false|none||none|
|» state|string|false|none||none|
|» avatar_url|string|false|none||none|
|» web_url|string|false|none||none|
|» membership_state|string|false|none||none|

## GET 列出所有群组项目

GET /api/v4/groups/{id}/projects

### 请求参数

|名称|位置|类型|必选|说明|
|---|---|---|---|---|
|id|path|string| 是 |none|
|Authorization|header|string| 否 |none|
|Content-Type|header|string| 否 |none|

> 返回示例

> 200 Response

```json
{}
```

### 返回结果

|状态码|状态码含义|说明|数据模型|
|---|---|---|---|
|200|[OK](https://tools.ietf.org/html/rfc7231#section-6.3.1)|成功|Inline|

### 返回数据结构

# 数据模型

